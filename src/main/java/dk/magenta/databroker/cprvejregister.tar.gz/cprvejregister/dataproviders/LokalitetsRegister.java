package dk.magenta.databroker.cprvejregister.dataproviders;

import dk.magenta.databroker.core.model.DataProviderEntity;
import dk.magenta.databroker.cprvejregister.dataproviders.records.*;
import dk.magenta.databroker.cprvejregister.dataproviders.objectcontainers.*;
import dk.magenta.databroker.cprvejregister.model.AdresseEntity;
import dk.magenta.databroker.cprvejregister.model.HusnummerEntity;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;

/**
 * Created by lars on 04-11-14.
 */
public class LokalitetsRegister extends CprRegister {


    public class Lokalitet extends Record {
        public static final String RECORDTYPE_LOKALITET = "001";
        public String getRecordType() {
            return RECORDTYPE_LOKALITET;
        }
        private int kommuneKode;
        private int vejKode;
        private String myndighedsNavn;
        private String vejadresseringsNavn;
        private String husNr;
        private String etage;
        private String sidedoer;
        private String lokalitet;

        public int getKommuneKode() {
            return this.kommuneKode;
        }
        public int getVejKode() {
            return this.vejKode;
        }
        public String getMyndighedsNavn() {
            return this.myndighedsNavn;
        }
        public String getVejadresseringsNavn() {
            return this.vejadresseringsNavn;
        }
        public String getHusNr() {
            return this.husNr;
        }
        public String getEtage() {
            return this.etage;
        }
        public String getSidedoer() {
            return this.sidedoer;
        }
        public String getLokalitet() {
            return this.lokalitet;
        }

        public Lokalitet(String line) throws ParseException {
            super(line);
            this.kommuneKode = Integer.parseInt(substr(line, 4, 4), 10);
            this.vejKode = Integer.parseInt(substr(line, 8, 4), 10);
            this.myndighedsNavn = substr(line, 12, 20);
            this.vejadresseringsNavn = substr(line, 32, 20);
            this.husNr = substr(line, 52, 4);
            this.etage = substr(line, 56, 2);
            this.sidedoer = substr(line, 58, 4);
            this.lokalitet = substr(line, 62, 34);
        }
    }

    private class KommuneContainer extends Level3Container<HusnummerEntity> {
    }

    public LokalitetsRegister(DataProviderEntity dbObject) {
        super(dbObject);
    }

    public URL getRecordUrl() throws MalformedURLException {
        return new URL("https://cpr.dk/media/152108/a370714.txt");
    }

    protected Record parseTrimmedLine(String recordType, String line) {
        Record r = super.parseTrimmedLine(recordType, line);
        if (r != null) {
            return r;
        }
        try {
            if (recordType.equals(Lokalitet.RECORDTYPE_LOKALITET)) {
                return new Lokalitet(line);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected void saveRunToDatabase(RegisterRun run) {

        try {
            KommuneContainer created = new KommuneContainer();
            for (Record record : run.getAll()) {
                if (record.getRecordType().equals(Lokalitet.RECORDTYPE_LOKALITET)) {
                    Lokalitet lokalitet = (Lokalitet) record;
                    int kommuneKode = lokalitet.getKommuneKode();
                    int vejKode = lokalitet.getVejKode();
                    String husKode = lokalitet.getHusNr();

                    HusnummerEntity husNummerEntity = created.get(kommuneKode, vejKode, husKode);
                    if (husNummerEntity == null) {
                        husNummerEntity = new HusnummerEntity();
                        husNummerEntity.setHusnummerbetegnelse(husKode);
                        // find NavngivenVej med kommuneKode og vejKode i databasen
                        // husNummerEntity.setNavngivenVej();
                        created.put(kommuneKode, vejKode, husKode, husNummerEntity);
                    }
                    AdresseEntity adresseEntity = new AdresseEntity();
                    adresseEntity.setDoerbetegnelse(lokalitet.getSidedoer());
                    adresseEntity.setEtagebetegnelse(lokalitet.getEtage());
                    adresseEntity.setHusnummer(husNummerEntity);
                    // Gem adresseEntity i databasen
                }
            }
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        LokalitetsRegister register = new LokalitetsRegister(null);
        register.pull();
        System.out.println("Finished");
    }
}
