package dk.magenta.databroker.cprvejregister.dataproviders;

import dk.magenta.databroker.core.model.DataProviderEntity;
import dk.magenta.databroker.cprvejregister.dataproviders.records.Record;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;

/**
 * Created by lars on 04-11-14.
 */
public class BynavnRegister extends CprRegister {

    public class ByNavn extends Record {
        public static final String RECORDTYPE_BYNAVN = "001";
        public String getRecordType() {
            return RECORDTYPE_BYNAVN;
        }
        private int kommuneKode;
        private int vejKode;
        private String myndighedsNavn;
        private String vejadresseringsNavn;
        private String husNrFra;
        private String husNrTil;
        private boolean ulige;
        private String byNavn;

        public int getKommuneKode() {
            return this.kommuneKode;
        }
        public int getVejKode() {
            return this.vejKode;
        }
        public String getMyndighedsNavn() {
            return this.myndighedsNavn;
        }
        public String getVejadresseringsNavn() {
            return this.vejadresseringsNavn;
        }
        public String getHusNrFra() {
            return this.husNrFra;
        }
        public String getHusNrTil() {
            return this.husNrTil;
        }
        public boolean isUlige() {
            return this.ulige;
        }
        public String getByNavn() {
            return this.byNavn;
        }

        public ByNavn(String line) throws ParseException {
            super(line);
            this.kommuneKode = Integer.parseInt(substr(line, 4, 4), 10);
            this.vejKode = Integer.parseInt(substr(line, 8, 4), 10);
            this.myndighedsNavn = substr(line, 12, 20);
            this.vejadresseringsNavn = substr(line, 32, 20);
            this.husNrFra = substr(line, 52, 4);
            this.husNrTil = substr(line, 56, 4);
            this.ulige = substr(line, 60, 1).equalsIgnoreCase("U");
            this.byNavn = substr(line, 61, 34);
        }
    }

    public BynavnRegister(DataProviderEntity dbObject) {
        super(dbObject);
    }

    public URL getRecordUrl() throws MalformedURLException {
        return new URL("https://cpr.dk/media/152120/a370713.txt");
    }

    protected Record parseTrimmedLine(String recordType, String line) {
        Record r = super.parseTrimmedLine(recordType, line);
        if (r != null) {
            return r;
        }
        try {
            if (recordType.equals(ByNavn.RECORDTYPE_BYNAVN)) {
                return new ByNavn(line);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        new BynavnRegister(null).pull();
    }
}
