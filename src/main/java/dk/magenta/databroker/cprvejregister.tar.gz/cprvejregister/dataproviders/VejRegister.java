package dk.magenta.databroker.cprvejregister.dataproviders;
import dk.magenta.databroker.cprvejregister.dataproviders.objectcontainers.*;

import dk.magenta.databroker.core.model.DataProviderEntity;
import dk.magenta.databroker.cprvejregister.dataproviders.records.Record;
import dk.magenta.databroker.cprvejregister.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;


/**
 * Created by lars on 04-11-14.
 */
public class VejRegister extends CprRegister {


    public abstract class VejDataRecord extends Record {
        public static final String RECORDTYPE_AKTVEJ = "001";
        public static final String RECORDTYPE_BOLIG = "002";
        public static final String RECORDTYPE_BYDISTRIKT = "003";
        public static final String RECORDTYPE_POSTDIST = "004";
        public static final String RECORDTYPE_NOTATVEJ = "005";
        public static final String RECORDTYPE_BYFORNYDIST = "006";
        public static final String RECORDTYPE_DIVDIST = "007";
        public static final String RECORDTYPE_EVAKUERDIST = "008";
        public static final String RECORDTYPE_KIRKEDIST = "009";
        public static final String RECORDTYPE_SKOLEDIST = "010";
        public static final String RECORDTYPE_BEFOLKDIST = "011";
        public static final String RECORDTYPE_SOCIALDIST = "012";
        public static final String RECORDTYPE_SOGNEDIST = "013";
        public static final String RECORDTYPE_VALGDIST = "014";
        public static final String RECORDTYPE_VARMEDIST = "015";
        public static final String RECORDTYPE_HISTORISKVEJ = "016";
        protected int getTimestampStart() {
            return 21;
        }

        private int kommuneKode;
        private int vejKode;
        private String timestamp;

        public int getKommuneKode() {
            return this.kommuneKode;
        }
        public int getVejKode() {
            return this.vejKode;
        }
        public String getTimestamp() {
            return this.timestamp;
        }

        public VejDataRecord(String line) throws ParseException {
            super(line);
            this.kommuneKode = Integer.parseInt(substr(line, 4, 4), 10);
            this.vejKode = Integer.parseInt(substr(line, 8, 4), 10);
            this.timestamp = substr(line, this.getTimestampStart(), 12);
        }
    }

    public abstract class Distrikt extends VejDataRecord {
        protected int getDistriktsTekstStart() { return 35; }
        protected int getDistriktsTekstLength() {
            return 30;
        }

        private int husNrFra;
        private int husNrTil;
        private boolean ulige;
        private String distriktsTekst;

        public int getHusNrFra() {
            return this.husNrFra;
        }
        public int getHusNrTil() {
            return this.husNrTil;
        }
        public boolean isUlige() {
            return this.ulige;
        }
        public String getDistriktsTekst() {
            return this.distriktsTekst;
        }

        public Distrikt(String line) throws ParseException {
            super(line);
            this.husNrFra = Integer.parseInt(substr(line, 12, 4), 10);
            this.husNrTil = Integer.parseInt(substr(line, 16, 4), 10);
            this.ulige = substr(line, 20, 1).equalsIgnoreCase("U");
            this.distriktsTekst = substr(line, this.getDistriktsTekstStart(), this.getDistriktsTekstLength());
        }
    }

    public class AktivVej extends VejDataRecord {
        public String getRecordType() {
            return RECORDTYPE_AKTVEJ;
        }
        protected int getTimestampStart() {
            return 12;
        }

        private int tilKommuneKode;
        private int tilVejKode;
        private int fraKommuneKode;
        private int fraVejKode;
        private String startDato;
        private String vejAdresseringsnavn;
        private String vejNavn;

        public int getTilKommuneKode() {
            return this.tilKommuneKode;
        }
        public int getTilVejKode() {
            return this.tilVejKode;
        }
        public int getFraKommuneKode() {
            return this.fraKommuneKode;
        }
        public int getFraVejKode() {
            return this.fraVejKode;
        }
        public String getStartDato() {
            return this.startDato;
        }
        public String getVejAdresseringsnavn() {
            return this.vejAdresseringsnavn;
        }
        public String getVejNavn() {
            return this.vejNavn;
        }

        public AktivVej(String line) throws ParseException {
            super(line);
            this.tilKommuneKode = Integer.parseInt(substr(line, 24, 4), 10);
            this.tilVejKode = Integer.parseInt(substr(line, 28, 4), 10);
            this.fraKommuneKode = Integer.parseInt(substr(line, 32, 4), 10);
            this.fraVejKode = Integer.parseInt(substr(line, 36, 4), 10);
            this.startDato = substr(line, 40, 12);
            this.vejAdresseringsnavn = substr(line, 52, 20);
            this.vejNavn = substr(line, 72, 40);
        }
    }

    public class Bolig extends VejDataRecord {
        public String getRecordType() {
            return RECORDTYPE_BOLIG;
        }
        protected int getTimestampStart() {
            return 22;
        }
        private String husNr;
        private String etage;
        private String sidedoer;
        private String startDato;
        private String lokalitet;

        public String getHusNr() {
            return this.husNr;
        }
        public String getEtage() {
            return this.etage;
        }
        public String getSidedoer() {
            return this.sidedoer;
        }
        public String getStartDato() {
            return this.startDato;
        }
        public String getLokalitet() {
            return this.lokalitet;
        }

        public Bolig(String line) throws ParseException {
            super(line);
            this.husNr = substr(line, 12, 4);
            this.etage = substr(line, 16, 2);
            this.sidedoer = substr(line, 18, 4);
            this.startDato = substr(line, 35, 12);
            this.lokalitet = substr(line, 59, 34);
        }
    }

    public class ByDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_BYDISTRIKT;
        }
        protected int getDistriktsTekstStart() {
            return 33;
        }
        protected int getDistriktsTekstLength() {
            return 34;
        }
        private String bynavn;

        public String getBynavn() {
            return this.bynavn;
        }

        public ByDistrikt(String line) throws ParseException {
            super(line);
            this.bynavn = this.getDistriktsTekst();
        }
    }

    public class PostDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_POSTDIST;
        }
        protected int getDistriktsTekstStart() {
            return 37;
        }
        protected int getDistriktsTekstLength() {
            return 20;
        }
        private int postNr;

        public int getPostNr() {
            return this.postNr;
        }

        public PostDistrikt(String line) throws ParseException {
            super(line);
            this.postNr = Integer.parseInt(substr(line, 33, 4));
        }
    }

    public class NotatVej extends VejDataRecord {
        public String getRecordType() {
            return RECORDTYPE_NOTATVEJ;
        }
        protected int getTimestampStart() {
            return 54;
        }
        private int notatNr;
        private String notatLinie;
        private String startDato;

        public int getNotatNr() {
            return this.notatNr;
        }
        public String getNotatLinie() {
            return this.notatLinie;
        }
        public String getStartDato() {
            return this.startDato;
        }

        public NotatVej(String line) throws ParseException {
            super(line);
            this.notatNr = Integer.parseInt(substr(line, 12, 2), 10);
            this.notatLinie = substr(line, 14, 40);
            this.startDato = substr(line, 66, 12);
        }
    }

    public class ByfornyelsesDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_BYFORNYDIST;
        }
        protected int getDistriktsTekstStart() {
            return 39;
        }
        private String byfornyKode;
        public ByfornyelsesDistrikt(String line) throws ParseException {
            super(line);
            this.byfornyKode = substr(line, 33, 6);
            System.out.println("Byfornykode: "+this.byfornyKode);
        }
    }

    public class DiverseDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_DIVDIST;
        }
        protected int getDistriktsTekstStart() {
            return 39;
        }
        private String distriktsType;
        private String diverseDistriktsKode;
        public DiverseDistrikt(String line) throws ParseException {
            super(line);
            this.distriktsType = substr(line, 33, 2);
            this.diverseDistriktsKode = substr(line, 35, 4);
            System.out.println("distriktsType: "+this.distriktsType);
            System.out.println("diverseDistriktsKode: "+this.diverseDistriktsKode);
        }
    }

    public class EvakueringsDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_EVAKUERDIST;
        }
        protected int getDistriktsTekstStart() {
            return 34;
        }
        private String evakueringsKode;
        public EvakueringsDistrikt(String line) throws ParseException {
            super(line);
            this.evakueringsKode = substr(line, 33, 1);
            System.out.println("evakueringsKode: "+this.evakueringsKode);
        }
    }

    public class KirkeDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_KIRKEDIST;
        }
        private String kirkeKode;
        public KirkeDistrikt(String line) throws ParseException {
            super(line);
            this.kirkeKode = substr(line, 33, 2);
            System.out.println("kirkeKode: "+this.kirkeKode);
        }
    }

    public class SkoleDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_SKOLEDIST;
        }
        private String skoleKode;
        public SkoleDistrikt(String line) throws ParseException {
            super(line);
            this.skoleKode = substr(line, 33, 2);
            System.out.println("skoleKode: "+this.skoleKode);
        }
    }

    public class BefolkningsDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_BEFOLKDIST;
        }
        protected int getDistriktsTekstStart() {
            return 37;
        }
        private String befolkningsKode;
        public BefolkningsDistrikt(String line) throws ParseException {
            super(line);
            this.befolkningsKode = substr(line, 33, 4);
            System.out.println("befolkningsKode: "+this.befolkningsKode);
        }
    }

    public class SocialDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_SOCIALDIST;
        }
        private String socialKode;
        public SocialDistrikt(String line) throws ParseException {
            super(line);
            this.socialKode = substr(line, 33, 2);
            System.out.println("socialKode: "+this.socialKode);
        }
    }

    public class SogneDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_SOGNEDIST;
        }
        protected int getDistriktsTekstStart() {
            return 37;
        }
        protected int getDistriktsTekstLength() {
            return 20;
        }
        private String myndighedsKode;
        private String myndighedsNavn;
        public SogneDistrikt(String line) throws ParseException {
            super(line);
            this.myndighedsKode = substr(line, 33, 4);
            System.out.println("myndighedsKode: "+this.myndighedsKode);
            this.myndighedsNavn = this.getDistriktsTekst();
        }
    }

    public class ValgDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_VALGDIST;
        }
        private String valgKode;
        public ValgDistrikt(String line) throws ParseException {
            super(line);
            this.valgKode = substr(line, 33, 2);
            System.out.println("valgKode: "+this.valgKode);
        }
    }

    public class VarmeDistrikt extends Distrikt {
        public String getRecordType() {
            return RECORDTYPE_VARMEDIST;
        }
        protected int getDistriktsTekstStart() {
            return 37;
        }
        private String varmeKode;
        public VarmeDistrikt(String line) throws ParseException {
            super(line);
            this.varmeKode = substr(line, 33, 4);
            System.out.println("varmeKode: "+this.varmeKode);

        }
    }

    public class HistoriskVej extends VejDataRecord {
        public String getRecordType() {
            return RECORDTYPE_HISTORISKVEJ;
        }
        protected int getTimestampStart() {
            return 12;
        }
        private String startDato;
        private String slutDato;
        private String vejAdresseringsnavn;
        private String vejNavn;
        public HistoriskVej(String line) throws ParseException {
            super(line);
            this.startDato = substr(line, 24, 12);
            this.slutDato = substr(line, 36, 12);
            this.vejAdresseringsnavn = substr(line, 48, 20);
            this.vejNavn = substr(line, 68, 40);
        }
    }

    public class VejRegisterRun extends RegisterRun {

        private Level2Container<AktivVej> aktiveVeje;
        public VejRegisterRun() {
            super();
            this.aktiveVeje = new Level2Container<AktivVej>();
        }
        public void saveRecord(Record record) {
            if (record.getRecordType().equals(VejDataRecord.RECORDTYPE_AKTVEJ)) {
                this.saveRecord((AktivVej) record);
            }
        }
        public void saveRecord(AktivVej vej) {
            super.saveRecord(vej);
            int vejKode = vej.getVejKode();
            int kommuneKode = vej.getKommuneKode();
            if (!aktiveVeje.put(kommuneKode, vejKode, vej, true)) {
                System.out.println("Collision on kommuneKode "+kommuneKode+", vejKode "+vejKode+" ("+aktiveVeje.get(kommuneKode, vejKode).getVejNavn()+" vs "+vej.getVejNavn()+")");
            }
        }

        public Level2Container<AktivVej> getAktiveVeje() {
            return aktiveVeje;
        }

        public void setAktiveVeje(Level2Container<AktivVej> aktiveVeje) {
            this.aktiveVeje = aktiveVeje;
        }
/*
        public VejRegister.AktivVej getAktivVej(String kommuneKode, String vejKode) {
            return this.aktiveVeje.get(kommuneKode, vejKode);
        }
        public Set<Integer> getKommuneKoder() {
            return (Set<String>) this.aktiveVeje.keySet();
        }
        public Set<String> getVejKoder(String kommuneKode) {
            if (this.aktiveVeje.containsKey(kommuneKode)) {
                return this.aktiveVeje.get(kommuneKode).keySet();
            }
            return null;
        }*/
    }

    //------------------------------------------------------------------------------------------------------------------

    private class KommuneContainer extends Level2Container<KommunedelAfNavngivenVejEntity> {
    }

    //------------------------------------------------------------------------------------------------------------------
    public VejRegister(DataProviderEntity dbObject) {
        super(dbObject);
    }

    public URL getRecordUrl() throws MalformedURLException {
        return new URL("https://cpr.dk/media/152096/vejregister_hele_landet_pr_141101.zip");
    }

    protected RegisterRun createRun() {
        return new VejRegisterRun();
    }

    protected Record parseTrimmedLine(String recordType, String line) {
        Record r = super.parseTrimmedLine(recordType, line);
        if (r != null) {
            return r;
        }
        try {
            if (recordType.equals(VejDataRecord.RECORDTYPE_AKTVEJ)) {
                return new AktivVej(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_BOLIG)) {
                return new Bolig(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_BYDISTRIKT)) {
                return new ByDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_POSTDIST)) {
                return new PostDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_NOTATVEJ)) {
                return new NotatVej(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_BYFORNYDIST)) {
                return new ByfornyelsesDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_DIVDIST)) {
                return new DiverseDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_EVAKUERDIST)) {
                return new EvakueringsDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_KIRKEDIST)) {
                return new KirkeDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_SKOLEDIST)) {
                return new SkoleDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_BEFOLKDIST)) {
                return new BefolkningsDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_SOCIALDIST)) {
                return new SocialDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_SOGNEDIST)) {
                return new SogneDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_VALGDIST)) {
                return new ValgDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_VARMEDIST)) {
                return new VarmeDistrikt(line);
            }
            if (recordType.equals(VejDataRecord.RECORDTYPE_HISTORISKVEJ)) {
                return new HistoriskVej(line);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected void saveRunToDatabase(RegisterRun run, List<JpaRepository> repositories) {
        try {
            VejRegisterRun vrun = (VejRegisterRun) run;
            KommuneContainer created = new KommuneContainer();


            KommunedelAfNavngivenVejRepository kommunedelAfNavngivenVejRepository = null;
            NavngivenVejRepository navngivenVejRepository = null;

            for (JpaRepository repository : repositories) {
                try {
                    kommunedelAfNavngivenVejRepository = (KommunedelAfNavngivenVejRepository) repository;
                } catch (ClassCastException e) {}
                try {
                    navngivenVejRepository = (NavngivenVejRepository) repository;
                } catch (ClassCastException e) {}
            }
            if (kommunedelAfNavngivenVejRepository == null || navngivenVejRepository == null) {
                System.err.println("Insufficient repositories");
                return;
            }

            List<KommunedelAfNavngivenVejEntity> kmdVejEntities = kommunedelAfNavngivenVejRepository.findAll();
            Level2Container<KommunedelAfNavngivenVejEntity> existingKmdVejMap = new Level2Container<KommunedelAfNavngivenVejEntity>();
            for (KommunedelAfNavngivenVejEntity entity : kmdVejEntities) {
                existingKmdVejMap.put(""+entity.getKommune().getKommunekode(), ""+entity.getVejkode(), entity);
            }

            Level2Container<AktivVej> aktiveVeje = vrun.getAktiveVeje();
            for (int kommuneKode : aktiveVeje.keySet()) {
                for (int vejKode : aktiveVeje.get(kommun).keySet()) {
                    AktivVej aktivVej = aktiveVeje.get(kommuneKode, vejKode);
                    if (aktivVej != null) {
                        navngivenVejRepository.
                        //System.out.println("NavngivenVej(" + aktivVej.get("vejKode") + ", " + aktivVej.get("vejNavn") + ")");
                        String vejPrint = "NavngivenVej(" + aktivVej.get("vejKode") + ", " + aktivVej.get("vejNavn") + ")";


                        /*Registrering registrering = new Registrering();
                        Virkning virkning = new Virkning();
                        Vejnavneomraade vejnavneomraade = new Vejnavneomraade();
                        String navngivenVejUuid = UUID.randomUUID().toString();
                        Kommune kommune = this.findKommune(1234);
                        System.out.println("NavngivenVej("+registrering+", "+virkning+", "+kommune+", "+vejnavneomraade+", "+navngivenVejUuid+")");*/
                        KommunedelAfNavngivenVejEntity kommunedelAfNavngivenVejEntity = new KommunedelAfNavngivenVejEntity();
                        // Find kommune med kommuneKode
                        //kommunedelAfNavngivenVejEntity.setKommune();
                        kommunedelAfNavngivenVejEntity.setVejkode(Integer.parseInt(vejKode, 10));


                        // Vi har nu skabt en NavngivenVej-instans. Gem den somehow
                        created.put(kommuneKode, vejKode, kommunedelAfNavngivenVejEntity);

                    }
                }
            }


            System.out.println(created.get("0153", "0196"));


            for (String kommuneKode : vrun.getKommuneKoder()) {
                for (String vejKode : vrun.getVejKoder(kommuneKode)) {
                    AktivVej aktivVej = vrun.getAktivVej(kommuneKode, vejKode);
                    if (aktivVej != null) {

                        KommunedelAfNavngivenVejEntity kommunedelAfNavngivenVejEntity = created.get(kommuneKode, vejKode);

                        NavngivenVejEntity navngivenVejEntity = null;

                        String fraKommuneKode = aktivVej.get("fraKommuneKode");
                        if (!fraKommuneKode.isEmpty() && !fraKommuneKode.equals("0000")) {
                            String fraVejKode = aktivVej.get("fraVejKode");
                            if (!fraVejKode.isEmpty() && !fraVejKode.equals("0000")) {
                                AktivVej other = vrun.getAktivVej(fraKommuneKode, fraVejKode);
                                if (other != null) {
                                    KommunedelAfNavngivenVejEntity andenVej = created.get(fraKommuneKode, fraVejKode);
                                    if (navngivenVejEntity == null) {
                                        if (andenVej != null) {
                                            navngivenVejEntity = andenVej.getNavngivenVej();
                                        }
                                    }
                                } else {
                                    System.out.println("    fra vej: (" + fraKommuneKode + ", " + fraVejKode + ") doesn't exist");
                                }
                            }
                        }

                        String tilKommuneKode = aktivVej.get("tilKommuneKode");
                        if (!tilKommuneKode.isEmpty() && !tilKommuneKode.equals("0000")) {
                            String tilVejKode = aktivVej.get("tilVejKode");
                            if (!tilVejKode.isEmpty() && !tilVejKode.equals("0000")) {
                                AktivVej other = vrun.getAktivVej(tilKommuneKode, tilVejKode);
                                if (other != null) {
                                    KommunedelAfNavngivenVejEntity andenVej = created.get(tilKommuneKode, tilVejKode);
                                    if (navngivenVejEntity == null) {
                                        if (andenVej != null) {
                                            navngivenVejEntity = andenVej.getNavngivenVej();
                                            //System.out.println("b ETABLERES: ("+tilKommuneKode+", "+tilVejKode+") <=> ("+kommuneKode+", "+vejKode+")");
                                        }
                                    }
                                } else {
                                    System.out.println("    til vej: (" + tilKommuneKode + ", " + tilVejKode + ") doesn't exist");
                                }
                            }
                        }

                        if (navngivenVejEntity == null) {
                            navngivenVejEntity = new NavngivenVejEntity();
                            navngivenVejEntity.setVejnavn(aktivVej.get("vejNavn"));
                            navngivenVejEntity.setVejaddresseringsnavn(aktivVej.get("vejAdresseringsnavn"));
                            //navngivenVejEntity.setAnsvarligKommune();
                            // Gem navngivenVejEntity
                        }

                        kommunedelAfNavngivenVejEntity.setNavngivenVej(navngivenVejEntity);
                        // Gem kommunedelAfNavngivenVejEntity

                    } else {
                        System.out.println("NULL road at kommuneKode: "+kommuneKode+", vejKode: "+vejKode);
                    }
                }
            }
        } catch (ClassCastException e) {}
    }

    protected void processRecord(Record record) {
        if (record.getRecordType() == VejDataRecord.RECORDTYPE_AKTVEJ) {
            AktivVej vej = (AktivVej) record;
            //System.out.println("AktivVej("+vej.get("vejNavn")+")");
            //Registrering registrering = new Registrering();
            //Virkning virkning = new Virkning();
            //Vejnavneomraade vejnavneomraade = new Vejnavneomraade();
            //String navngivenVejUuid = UUID.randomUUID().toString();
            //Kommune kommune = this.findKommune(1234);
            //System.out.println("NavngivenVej("+registrering+", "+virkning+", "+kommune+", "+vejnavneomraade+", "+navngivenVejUuid+")");
            //NavngivenVej vej = new NavngivenVej(registrering, virkning, kommune, vejnavneomraade, navngivenVejUuid);
            // Vi har nu skabt en NavngivenVej-instans. Gem den somehow
        }
    }

    /*private Kommune findKommune(int kommuneKode) {
        //this.getDbObject().
        return null;
    }*/

    public static void main(String[] args) {
        new VejRegister(null).pull();
        System.out.println("Finished");
    }
}
